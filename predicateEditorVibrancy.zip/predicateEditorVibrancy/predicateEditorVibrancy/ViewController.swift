//
//  ViewController.swift
//  predicateEditorVibrancy
//
//  Created by Rachael Worthington on 7/31/18.
//  Copyright © 2018 The Omni Group. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {


    @IBOutlet weak var predicateEditor1: NSPredicateEditor!
    @IBOutlet weak var predicateEditor2: NSPredicateEditor!
    @IBOutlet weak var predicateEditor3: NSPredicateEditor!

    @IBOutlet weak var predicateEditor4: NSPredicateEditor!


    override func viewDidLoad() {
        super.viewDidLoad()

        let attribute = "name"
        let option = "Rey"
        let option2 = "Finn"

        predicateEditor1.objectValue = NSPredicate(format: "%K CONTAINS %@", attribute, option, option2)
        predicateEditor2.objectValue = NSPredicate(format: "%K CONTAINS %@", attribute, option, option2)
        predicateEditor3.objectValue = NSPredicate(format: "%K CONTAINS %@", attribute, option, option2)
        predicateEditor4.objectValue = NSPredicate(format: "%K CONTAINS %@", attribute, option, option2)

        // Do any additional setup after loading the view.
        let veView:NSVisualEffectView = NSVisualEffectView(frame: predicateEditor4.frame)
        veView.material = .sheet
        let parentView = predicateEditor4.superview;

        if let parentView = parentView {
            predicateEditor4.removeFromSuperview()
            veView.addSubview(predicateEditor4)
            parentView.addSubview(veView)
        }

    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}

