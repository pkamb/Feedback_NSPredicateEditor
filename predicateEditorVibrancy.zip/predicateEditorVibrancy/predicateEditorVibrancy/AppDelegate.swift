//
//  AppDelegate.swift
//  predicateEditorVibrancy
//
//  Created by Rachael Worthington on 7/31/18.
//  Copyright © 2018 The Omni Group. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

